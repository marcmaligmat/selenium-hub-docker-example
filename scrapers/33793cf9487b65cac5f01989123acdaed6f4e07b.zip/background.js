
  var config = {
          mode: "fixed_servers",
          rules: {
          singleProxy: {
              scheme: "http",
              host: "102.165.1.59",
              port: parseInt(5432)
          },
          bypassList: ["localhost"]
          }
      };

  chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

  function callbackFn(details) {
      return {
          authCredentials: {
              username: "gpfc8",
              password: "usas32wk"
          }
      };
  }

  chrome.webRequest.onAuthRequired.addListener(
              callbackFn,
              {urls: [""]},
              ['blocking']
  );
  